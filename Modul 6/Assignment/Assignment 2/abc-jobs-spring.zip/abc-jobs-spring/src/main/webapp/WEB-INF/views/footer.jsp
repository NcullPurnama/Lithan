	<section id="footer" class="mt-5">
    <div class="container">
      <div class="footer-content d-flex flex-column flex-md-row">
        <div class="footer-brand me-5 pe-lg-5 mb-2">
          <h2 class="fw-semibold">ABC Jobs</h2>
        </div>
        <div class="footer-links d-flex justify-content-between flex-wrap text-primary">
          <ul class="links text-primary" style="list-style-type= none">
            <span class="fw-semibold text-primary">General</span>
            <li><p class="text-primary">Sign up</p></li>
            <li><p class="text-primary">Help center</p></li>
            <li><p class="text-primary">About</p></li>
            <li><p class="text-primary">Developers</p></li>
            <li><p class="text-primary">Careers</p></li>
          </ul>
          <ul class="links">
            <span class="fw-semibold" style="list-style-type= none">Directories</span>
            <li><p class="text-primary">Jobs</p></li>
            <li><p class="text-primary">Articles</p></li>
            <li><p class="text-primary">Companies</p></li>
            <li><p class="text-primary">Topics</p></li>
            <li><p class="text-primary">Featured</p></li>
          </ul>
          <ul class="links">
            <span class="fw-semibold" style="list-style-type= none">Follow us</span>
            <li><p class="text-primary">Twitter</p></li>
            <li><p class="text-primary">Facebook</p></li>
            <li><p class="text-primary">Instagram</p></li>
            <li><p class="text-primary">Youtube</p></li>
          </ul>
          <ul class="links">
            <span class="fw-semibold" style="list-style-type= none">Legal</span>
            <li><p class="text-primary">Privacy policy</p></li>
            <li><p class="text-primary">Terms of service</p></li>
          </ul>
        </div>
      </div>
      <p class="mt-2">ABC Jobs 2022. All Rights Reserved</p>
    </div>
  </section>
