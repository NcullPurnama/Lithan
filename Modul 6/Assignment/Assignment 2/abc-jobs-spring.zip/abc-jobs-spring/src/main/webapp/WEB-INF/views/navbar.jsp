<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow py-3 px-5 mb-4">
   <div class="container-fluid">
     <a class="navbar-brand" href="#">ABC Jobs</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         <li class="nav-item">
           <a class="nav-link" aria-current="page" routerLink="/">Home</a>
         </li>
         <li class="nav-item">
           <a class="nav-link" href="<%= request.getContextPath() %>/search">Search</a>
         </li>
       </ul>
       <div>
         <a href="<%= request.getContextPath() %>/login"><button class="btn btn-light" type="button">Login</button></a>
         <a href="<%= request.getContextPath() %>/registration"><button class="btn btn-light" type="button">Sign Up</button></a>
       </div>
     </div>
   </div>
</nav>