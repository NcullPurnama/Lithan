<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
 
<head>
	<link 
    href="https://bootswatch.com/5/lux/bootstrap.min.css" 
    rel="stylesheet">
    
    <link href="css/style.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
   
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="/">ABC JOBS</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarColor01">
	      <ul class="navbar-nav me-auto">
	        <li class="nav-item">
	          <a class="nav-link active" href="#">Home
	            <span class="visually-hidden">(current)</span>
	          </a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">People</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Jobs</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Account</a>
	        </li>
	      </ul>
	    </div>
	      <button type="button" class="btn btn-outline-secondary">Login</button>
	      <button type="button" class="btn btn-outline-secondary">Register</button>
	  </div>
	</nav>
</body>    
    